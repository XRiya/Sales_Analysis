import './App.css';
import NumberManagement from './numbers';
function App() {
  return (
    <div className="App">
      <NumberManagement />
    </div>
  );
}

export default App;
